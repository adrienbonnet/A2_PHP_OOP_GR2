<?php

return [
    'dbname'    => 'cartman',
    'user'      => 'root',
    'password'  => 'toor',
    'host'      => 'localhost',
    'driver'    => 'pdo_mysql',
];